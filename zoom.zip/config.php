<?php
require_once 'vendor/autoload.php';
require_once "class-db.php";
  
define('CLIENT_ID', 'wr5I5zZBSp2oKQFYv2Xwgg');
define('CLIENT_SECRET', 'HcFRaZonLtgH4vtSX3B3hmA6RTZJ3uAa');
define('REDIRECT_URI', 'https://62ceaa8bf3a9.ngrok.io/zoom/callback.php');